

#include <GL/glew.h>

#include "scene.hpp"

#include "../../lib/opengl/glutils.hpp"
#include "../../lib/perlin/perlin.hpp"
#include "../../lib/interface/camera_matrices.hpp"
#include "../interface/myWidgetGL.hpp"
#include "../../lib/mesh/mesh_io.hpp"

#include <cmath>
#include <string>
#include <sstream>


using namespace cpe;

cpe::mesh scene::create_plane(float xmin, float xmax, float ymin, float ymax, int Nx, int Ny){
    // Bruit de perlin
    cpe::perlin Perlin(5,0.6f);

    cpe::mesh m;
    const float dx = xmax-xmin;
    const float dy = ymax-ymin;
    const float dxx = dx/float(Nx-1);

    //set data
    for(int kv=0; kv<Ny; ++kv){
        float const v = static_cast<float>(kv)/(Ny-1);
        //float u = xmin;
        for (int ku=0; ku<Nx; ++ku){
            //u+=dxx; //mettre juste u dans add_vertex
            float const u = static_cast<float>(ku)/(Nx-1); //mettre u*dx dans add_vertex
            m.add_vertex({u*dx, v*dy, Perlin(vec2(u,v))});
            //std::cout << xmin+u << " " << ymin+v*dy << std::endl;
            m.add_texture_coord({u,v});
            m.add_normal({0.0f,0.0f,1.0f});
        }
    }

    //set connectivity
    for (int kv=0; kv<Ny-1; ++kv){
        for(int ku=0; ku<Nx-1; ++ku){
            int const offset = ku+Nx*kv;
            triangle_index tri0 = {offset, offset+1, offset+Nx+1};
            triangle_index tri1 = {offset, offset+Nx+1, offset+Nx};
            m.add_triangle_index(tri0);
            m.add_triangle_index(tri1);
        }
    }
    return m;
}

void scene::load_scene()
{

    //*****************************************//
    // Preload default structure               //
    //*****************************************//
    texture_default = load_texture_file("data/white.jpg");
    shader_program_id = read_shader("shaders/shader_mesh.vert",
                                    "shaders/shader_mesh.frag");


    //*****************************************//
    // OBJ Mesh                                //
    //*****************************************//
    texture_dinosaur=load_texture_file("data/stegosaurus.jpg");
    mesh_dinosaur=load_mesh_file("data/stegosaurus.obj");
    mesh_dinosaur.transform_apply_auto_scale_and_center();
    mesh_dinosaur_opengl.fill_vbo(mesh_dinosaur);

    //*****************************************//
    // OFF Mesh                                //
    //*****************************************//
    mesh_camel=load_mesh_file("data/camel.off");
    mesh_camel.transform_apply_auto_scale_and_center();
    mesh_camel.transform_apply_scale(0.5f);
    mesh_camel.transform_apply_rotation({1.0f,0.0f,0.0f},-M_PI/2.0f);
    mesh_camel.transform_apply_rotation({0.0f,1.0f,0.0f}, 5*M_PI/6.0f);
    mesh_camel.transform_apply_translation({-0.55f,-0.0f,0.1f});
    mesh_camel.fill_color_xyz();
    mesh_camel_opengl.fill_vbo(mesh_camel);


    //*****************************************//
    // Generate user defined mesh              //
    //*****************************************//

    mesh_ground.add_vertex( {-1.0f,-0.25f,-1.0f} );
    mesh_ground.add_vertex( {-1.0f,-0.25f, 1.0f} );
    mesh_ground.add_vertex( { 1.0f,-0.25f, 1.0f} );
    mesh_ground.add_vertex( { 1.0f,-0.25f,-1.0f} );
    //note: we can use mesh.add_vertex({x,y,z})
    //          or mesh.add_vertex(vec3(x,y,z));

    mesh_ground.add_triangle_index({0,2,1});
    mesh_ground.add_triangle_index({0,3,2});

    mesh_ground.fill_empty_field_by_default();
    mesh_ground.fill_color( {0.8,0.9,0.8} );

    mesh_ground_opengl.fill_vbo(mesh_ground);

    // Create Plane
    texture_plane=load_texture_file("data/grass.jpg");

    mesh_plane = scene::create_plane(-5.0f, 5.0f, -5.0f, 5.0f, 500, 500);
    mesh_plane.fill_empty_field_by_default();
    //mesh_plane.fill_color_xyz();
    //mesh_plane.fill_color( {0.4,0.5,0.8} );
    mesh_plane_opengl.fill_vbo(mesh_plane);
}

void scene::draw_scene()
{
    //Setup uniform parameters
    glUseProgram(shader_program_id);                                                                           PRINT_OPENGL_ERROR();

    //Get cameras parameters (modelview,projection,normal).
    camera_matrices const& cam=pwidget->camera();

    //Set Uniform data to GPU
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"camera_modelview"),1,false,cam.modelview.pointer());     PRINT_OPENGL_ERROR();
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"camera_projection"),1,false,cam.projection.pointer());   PRINT_OPENGL_ERROR();
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"normal_matrix"),1,false,cam.normal.pointer());           PRINT_OPENGL_ERROR();


    //Draw the meshes
    //glBindTexture(GL_TEXTURE_2D,texture_dinosaur); PRINT_OPENGL_ERROR();
    //mesh_dinosaur_opengl.draw();

    //glBindTexture(GL_TEXTURE_2D,texture_default);  PRINT_OPENGL_ERROR();
    //mesh_camel_opengl.draw();
    //mesh_ground_opengl.draw();

    glBindTexture(GL_TEXTURE_2D,texture_plane);  PRINT_OPENGL_ERROR();
    mesh_plane_opengl.draw();
}


scene::scene()
    :shader_program_id(0)
{}


GLuint scene::load_texture_file(std::string const& filename)
{
    return pwidget->load_texture_file(filename);
}

void scene::set_widget(myWidgetGL* widget_param)
{
    pwidget=widget_param;
}


